
import io
import re
import os
from pdfminer.converter import TextConverter
from pdfminer.pdfinterp import PDFPageInterpreter
from pdfminer.pdfinterp import PDFResourceManager
from pdfminer.pdfpage import PDFPage



### input the name
print("write in which name you want to save") 
name=input();

# creating directory if they dont exist 
if not os.path.exists(os.path.join("work","pdf")):
    os.makedirs(os.path.join("work","pdf"))

# collect all pdf name 
file=open("pdflist.txt","w")
for f in os.listdir(os.path.join("work","pdf")):
    if f.endswith(".pdf"):
        file.write(os.path.join("work","pdf", f))
        file.write(os.path.join('\n'))

 

def extract_text_from_pdf(pdf_path):
    resource_manager = PDFResourceManager()
    fake_file_handle = io.StringIO()
    converter = TextConverter(resource_manager, fake_file_handle)
    page_interpreter = PDFPageInterpreter(resource_manager, converter)
    with open(pdf_path, 'rb') as fh:
        for page in PDFPage.get_pages(fh, 
                                      caching=True,
                                      check_extractable=True):
            page_interpreter.process_page(page)
        text = fake_file_handle.getvalue()
    # close open handles
    converter.close()
    fake_file_handle.close()
    if text:
        return text
if __name__ == '__main__':
    
    cdrp=name+".vcf"
    cfile=open(os.path.join("work",cdrp), "w+")
    
    phoneNumRegex = re.compile(r'01\d\d\d\d\d\d\d\d\dCERTIFICATE')
    phonefile=open("text.txt", "w+")
    file=open("pdflist.txt","r")
    contents =file.readlines()
    for i in contents:
        a=len(str(i))-1
        pdfname=i[:a:]
        pdfname=os.path.join("",pdfname)
        mo= (extract_text_from_pdf(pdfname) ) 
        numbermatch=(phoneNumRegex.findall(mo))
        i=0
        for number in numbermatch:
#            print(num[:11])
            i=i+1
            cfile.write("BEGIN:VCARD\n")
            cfile.write("VERSION:4.0\n")
            cfile.write("PRODID:ez-vcard 0.10.4\n")
            cfile.write("FN:"+name+" #"+ str(i)+"\n" )
            cfile.write("PHOTO:\n")
            cfile.write("TEL;TYPE=mobile:"+number[:11]+"\n")
            cfile.write("ADR:;;;;;;\n")
            cfile.write("END:VCARD\n")
            cfile.write(" \n")
           
            
            
            
            
            
        
#        print(numbermatch.group()[:11])



